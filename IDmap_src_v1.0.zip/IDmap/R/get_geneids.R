#' Get gene ids from probe ids
#'
#' \code{get_geneids} returns a list of gene ids for the input probe ids
#'
#' @param probeids,dataset,platform
#'
#' @return if the input dataset is in our platform list ,then the output will be a dataframe,
#' which includes a list of gene ids mapping to probe ids and other information
#'
#' @examples
#' data(package = "IDmap")
#' probeids <- c("1000_at","1001_at","1002_f_at")
#' datasets <- human_data_from_biopack
#' platform <- "hcg110"
#' geneids <- get_geneids(probeids,datasets,platform)
#' head(geneids)
#'
#' @export

get_geneids <- function (probeids,datasets,platform) {

  if (missing(probeids)){

    stop("No valid probeids passed in !")

  }

  if (missing(datasets)){

    stop("No valid datasets passed in !")

  }

  if (missing(platform)){

    stop("No valid platform passed in !")

  }


  plt_data <- datasets[datasets$platform==platform,]
  output_dat <- plt_data[which(plt_data$probe_id %in% probeids),]

  return(output_dat)

}
